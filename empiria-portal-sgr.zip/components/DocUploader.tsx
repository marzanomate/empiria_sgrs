'use client';

import { upload } from '@vercel/blob/client';
import { useRouter } from 'next/navigation';
import { useRef, useState } from 'react';

const ACCEPT = '.pdf,.jpg,.jpeg,.png,.webp,.heic,.xls,.xlsx,.doc,.docx,.csv,.txt,.zip';
const MAX = 50 * 1024 * 1024;

function safeName(name: string) {
  const clean = name
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^A-Za-z0-9._ -]+/g, '_')
    .replace(/\s+/g, ' ')
    .trim();
  return (clean || 'archivo').slice(-120);
}

export default function DocUploader({ token, clientId, docKey }: { token: string; clientId: string; docKey: string }) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  const [busy, setBusy] = useState<{ name: string; pct: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handle(files: FileList | File[]) {
    setError(null);
    const list = Array.from(files);
    for (const file of list) {
      if (file.size > MAX) {
        setError(`"${file.name}" supera los 50 MB.`);
        continue;
      }
      setBusy({ name: file.name, pct: 0 });
      try {
        const pathname = `clientes/${clientId}/${docKey}/${Date.now()}-${safeName(file.name)}`;
        await upload(pathname, file, {
          access: 'private',
          handleUploadUrl: '/api/upload',
          clientPayload: JSON.stringify({ token, docKey }),
          multipart: file.size > 8 * 1024 * 1024,
          onUploadProgress: (p) => setBusy({ name: file.name, pct: Math.round(p.percentage) }),
        });
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        setError(
          /content type/i.test(msg)
            ? `"${file.name}": formato no permitido. Usá PDF, imagen, Excel, Word o ZIP.`
            : `No se pudo subir "${file.name}". ${msg}`,
        );
      }
    }
    setBusy(null);
    router.refresh();
  }

  return (
    <div>
      <div
        className={`drop ${over ? 'over' : ''}`}
        onClick={() => !busy && inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setOver(false);
          if (!busy && e.dataTransfer.files.length) handle(e.dataTransfer.files);
        }}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={ACCEPT}
          onChange={(e) => {
            if (e.target.files?.length) handle(e.target.files);
            e.target.value = '';
          }}
        />
        {busy ? (
          <span>Subiendo {busy.name}… {busy.pct}%</span>
        ) : (
          <span>Arrastrá los archivos acá o <u>hacé clic para elegirlos</u> · PDF, imagen, Excel, Word o ZIP · hasta 50 MB</span>
        )}
      </div>
      {error && <div className="notice bad small">{error}</div>}
    </div>
  );
}
