'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function DeleteFileButton({ token, pathname }: { token: string; pathname: string }) {
  const router = useRouter();
  const [state, setState] = useState<'idle' | 'ask' | 'busy'>('idle');
  if (state === 'ask')
    return (
      <span className="row" style={{ gap: 6 }}>
        <span className="small muted">¿Borrar?</span>
        <button
          className="btn danger sm"
          type="button"
          onClick={async () => {
            setState('busy');
            await fetch(`/api/c/${token}/file?pathname=${encodeURIComponent(pathname)}`, { method: 'DELETE' });
            router.refresh();
            setState('idle');
          }}
        >
          Sí
        </button>
        <button className="btn secondary sm" type="button" onClick={() => setState('idle')}>No</button>
      </span>
    );
  return (
    <button className="btn secondary sm" type="button" disabled={state === 'busy'} onClick={() => setState('ask')}>
      {state === 'busy' ? 'Borrando…' : 'Quitar'}
    </button>
  );
}
