# Empiria · Portal de documentación SGR

Plataforma para que los clientes suban la documentación de su legajo y el equipo de Empiria la revise y la descargue ordenada por SGR.

## Cómo funciona

**Cliente** (`/c/<link-único>`)
- Entra con un link personal, sin crear cuenta.
- Ve la lista de documentos que piden las SGRs a las que se presenta. Cada documento se sube una sola vez, aunque lo pidan varias.
- Arrastra los archivos (PDF, imagen, Excel, Word, ZIP; hasta 50 MB cada uno) y ve el estado de cada documento: Pendiente, En revisión, Aprobado u Observado (con el comentario de Empiria).
- Puede quitar archivos mientras el documento no esté aprobado.

**Equipo Empiria** (`/admin`, con contraseña)
- **Clientes:** alta con razón social, CUIT, contacto y SGRs; link único con botón de copiar; link nuevo si hace falta (el anterior deja de andar); activar o desactivar el link.
- **Revisión:** por documento, ver o bajar cada archivo, aprobar u observar con un comentario que el cliente ve en su portal. Si el cliente sube un archivo nuevo, el documento vuelve a "En revisión".
- **Legajo ZIP por SGR:** carpetas numeradas en el orden del checklist de esa SGR (`01 - Estatuto…/archivo.pdf`) más un `00 - Indice del legajo.txt` con el estado de cada documento y los obligatorios que faltan. Se puede bajar completo o solo con lo aprobado.
- **SGRs:** cada una con su checklist (qué pide, si es obligatorio y una nota para el cliente). Al crear una SGR se puede copiar el checklist de otra. Trae una "Plantilla estándar" precargada.
- **Documentos:** catálogo común (20 documentos típicos de un legajo SGR precargados), que se puede editar o ampliar.

## Almacenamiento y seguridad
- Todo se guarda en **Vercel Blob con acceso privado**: los archivos no tienen URL pública y solo se descargan a través de la app (el admin con su sesión, el cliente con su link).
- La configuración (clientes, SGRs, revisiones) vive en `sistema/db.json` dentro del mismo Blob, con escritura condicional (`ifMatch`) para que dos personas editando a la vez no se pisen. No hace falta una base de datos aparte.
- La carga va directo del navegador a Blob. El servidor valida antes que el link sea válido, que el documento esté pedido y no aprobado, la ruta, el tipo de archivo y el tamaño.
- Los links de cliente tienen 144 bits aleatorios. La sesión del admin es una cookie HttpOnly firmada con HMAC que dura 12 horas.

## Despliegue en Vercel (unos 10 minutos)

1. Subí esta carpeta a un repo privado de GitHub e importalo en Vercel (**Add New → Project**). El framework se detecta solo (Next.js).
2. En el proyecto: **Storage → Create → Blob**, elegí **Private** (región São Paulo, `gru1`, si está disponible) y conectalo al proyecto. Eso crea `BLOB_READ_WRITE_TOKEN`.
3. En **Settings → Environment Variables** agregá:
   - `ADMIN_PASSWORD`: la contraseña del equipo.
   - `ADMIN_SECRET`: una cadena aleatoria larga (por ejemplo, la salida de `openssl rand -hex 32`).
   - `PUBLIC_BASE_URL` (opcional): el dominio final, por ejemplo `https://documentos.empiria.com.ar`, para que los links de cliente usen ese dominio.
4. Volvé a desplegar (**Deployments → Redeploy**).
5. Entrá a `/admin`, revisá la "Plantilla estándar" en **SGRs**, creá tus SGRs reales copiando esa plantilla y dá de alta el primer cliente.

> Ojo: si dejás activado **Vercel Authentication** para todos los dominios, los clientes van a ver un login de Vercel. La opción por defecto ("Standard Protection") deja libre el dominio de producción y está bien así.

## Desarrollo local
```bash
npm install
# .env.local con BLOB_READ_WRITE_TOKEN, ADMIN_PASSWORD y ADMIN_SECRET
npm run dev
```

## Estructura
```
app/c/[token]/page.tsx          portal del cliente
app/admin/(panel)/...           panel interno: clientes, SGRs, documentos
app/admin/actions.ts            acciones del panel (todas validan la sesión)
app/api/upload/route.ts         token de carga directa a Blob, con validaciones
app/api/admin/zip/route.ts      armado del ZIP por SGR (streaming)
app/api/admin/file, api/c/...   descargas privadas y borrado
lib/defaults.ts                 catálogo inicial de documentos y plantilla
```

## Próximos pasos posibles
- Mail automático al cliente cuando se observa un documento, y a Empiria cuando el cliente sube algo.
- Vencimientos: balances, certificado MiPyME, F.931.
- Usuarios individuales del equipo con registro de quién aprobó cada cosa.
