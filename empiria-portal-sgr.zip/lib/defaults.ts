import type { Db, DocType } from './types';

export const DEFAULT_DOC_TYPES: DocType[] = [
  { key: 'solicitud_socio', label: 'Solicitud de incorporación como socio partícipe', description: 'Formulario de la SGR completo y firmado por el representante legal.' },
  { key: 'estatuto', label: 'Estatuto / contrato social y modificaciones', description: 'Con constancia de inscripción en IGJ o Registro Público correspondiente.' },
  { key: 'acta_autoridades', label: 'Última acta de designación de autoridades', description: 'Acta de asamblea y de directorio (o reunión de socios) con distribución de cargos, inscripta.' },
  { key: 'poderes', label: 'Poderes de apoderados', description: 'Solo si firma un apoderado.' },
  { key: 'dni_firmantes', label: 'DNI de autoridades, apoderados y fiadores', description: 'Frente y dorso, legibles.' },
  { key: 'nomina_socios', label: 'Composición accionaria / registro de accionistas', description: 'Nómina de socios con porcentajes de participación.' },
  { key: 'beneficiario_final', label: 'DDJJ de beneficiario final', description: 'Personas humanas con 10% o más del capital o los votos.' },
  { key: 'constancia_arca', label: 'Constancia de inscripción en ARCA', description: 'Constancia de CUIT actualizada.' },
  { key: 'iibb', label: 'Inscripción en Ingresos Brutos / Convenio Multilateral', description: 'Constancia de inscripción vigente.' },
  { key: 'certificado_mipyme', label: 'Certificado MiPyME vigente', description: 'Emitido por la Secretaría PyME.' },
  { key: 'balances', label: 'Últimos 3 estados contables', description: 'Firmados por contador y legalizados por el Consejo Profesional.' },
  { key: 'ventas_post_balance', label: 'Ventas mensuales post-balance', description: 'Detalle mes a mes desde el cierre del último balance, firmado por contador.' },
  { key: 'ddjj_iva', label: 'Últimas 12 DDJJ de IVA', description: 'Con acuse de recibo de ARCA.' },
  { key: 'ddjj_ganancias', label: 'Última DDJJ de Ganancias', description: 'Sociedad y, si corresponde, socios/fiadores.' },
  { key: 'f931', label: 'Últimas DDJJ de cargas sociales (F.931)', description: 'Últimos 3 meses con acuse.' },
  { key: 'deuda_financiera', label: 'Detalle de endeudamiento bancario y financiero', description: 'Entidad, monto, tasa, plazo y garantías. Firmado.' },
  { key: 'manifestacion_bienes', label: 'Manifestación de bienes de socios / fiadores', description: 'Certificada por contador.' },
  { key: 'ddjj_pep_uif', label: 'DDJJ PEP y sujeto obligado (UIF)', description: 'Firmadas por cada autoridad y fiador.' },
  { key: 'destino_fondos', label: 'Destino de los fondos', description: 'Nota breve describiendo el uso del financiamiento solicitado.' },
  { key: 'formularios_sgr', label: 'Otros formularios propios de la SGR', description: 'Cualquier formulario adicional que pida la SGR.' },
];

export function seedDb(): Db {
  return {
    version: 1,
    docTypes: DEFAULT_DOC_TYPES,
    sgrs: [
      {
        id: 'plantilla',
        name: 'Plantilla estándar',
        items: DEFAULT_DOC_TYPES.map((d) => ({
          docKey: d.key,
          required: !['poderes', 'formularios_sgr', 'destino_fondos'].includes(d.key),
        })),
        createdAt: new Date().toISOString(),
      },
    ],
    clients: [],
  };
}
