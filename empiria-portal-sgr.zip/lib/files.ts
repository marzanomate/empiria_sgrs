import 'server-only';
import { del, get, list } from '@vercel/blob';
import type { Client, DocStatus, StoredFile } from './types';

export const MAX_FILE_BYTES = 50 * 1024 * 1024;

export const ALLOWED_CONTENT_TYPES = [
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/heic',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/csv',
  'text/plain',
  'application/zip',
  'application/x-zip-compressed',
];

export function clientPrefix(clientId: string) {
  return `clientes/${clientId}/`;
}

export function parsePathname(pathname: string): StoredFile | null {
  const parts = pathname.split('/');
  if (parts.length < 4 || parts[0] !== 'clientes') return null;
  const docKey = parts[2];
  const raw = parts.slice(3).join('/');
  const name = raw.replace(/^\d{10,}-/, '');
  return { pathname, docKey, name, size: 0, uploadedAt: '' };
}

export async function listClientFiles(clientId: string): Promise<StoredFile[]> {
  const out: StoredFile[] = [];
  let cursor: string | undefined;
  do {
    const r = await list({ prefix: clientPrefix(clientId), cursor, limit: 1000 });
    for (const b of r.blobs) {
      const p = parsePathname(b.pathname);
      if (!p) continue;
      out.push({ ...p, size: b.size, uploadedAt: new Date(b.uploadedAt).toISOString() });
    }
    cursor = r.hasMore ? r.cursor : undefined;
  } while (cursor);
  out.sort((a, b) => a.uploadedAt.localeCompare(b.uploadedAt));
  return out;
}

export function groupByDoc(files: StoredFile[]) {
  const m: Record<string, StoredFile[]> = {};
  for (const f of files) (m[f.docKey] ??= []).push(f);
  return m;
}

export function docStatus(client: Client, docKey: string, files: StoredFile[] | undefined): DocStatus {
  if (!files || files.length === 0) return 'pendiente';
  const review = client.reviews[docKey];
  if (!review) return 'en_revision';
  const latest = files.reduce((acc, f) => (f.uploadedAt > acc ? f.uploadedAt : acc), '');
  if (latest > review.at) return 'en_revision';
  return review.status;
}

export async function streamFile(pathname: string, downloadName: string, inline = false) {
  const r = await get(pathname, { access: 'private' });
  if (!r || r.statusCode !== 200) return new Response('No encontrado', { status: 404 });
  const disp = `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(downloadName)}`;
  return new Response(r.stream, {
    headers: {
      'Content-Type': r.blob.contentType || 'application/octet-stream',
      'Content-Disposition': disp,
      'Cache-Control': 'private, no-store',
    },
  });
}

export async function deleteClientFolder(clientId: string) {
  const files = await listClientFiles(clientId);
  const paths = files.map((f) => f.pathname);
  for (let i = 0; i < paths.length; i += 100) await del(paths.slice(i, i + 100));
}

export { formatBytes, STATUS_LABEL } from './format';
