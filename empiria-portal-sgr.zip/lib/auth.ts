import 'server-only';
import crypto from 'crypto';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';

const COOKIE = 'empiria_admin';

function expected() {
  const secret = process.env.ADMIN_SECRET;
  const pass = process.env.ADMIN_PASSWORD;
  if (!secret || !pass) throw new Error('Faltan ADMIN_SECRET / ADMIN_PASSWORD');
  return crypto.createHmac('sha256', secret).update('admin-v1:' + pass).digest('hex');
}

function eq(a: string, b: string) {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
}

export async function isAdmin() {
  const v = (await cookies()).get(COOKIE)?.value;
  return !!v && eq(v, expected());
}

export async function requireAdmin() {
  if (!(await isAdmin())) redirect('/admin/login');
}

export function checkPassword(input: string) {
  const pass = process.env.ADMIN_PASSWORD ?? '';
  const a = crypto.createHash('sha256').update(input).digest();
  const b = crypto.createHash('sha256').update(pass).digest();
  return pass.length > 0 && crypto.timingSafeEqual(a, b);
}

export async function setAdminSession() {
  (await cookies()).set(COOKIE, expected(), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 12,
  });
}

export async function clearAdminSession() {
  (await cookies()).delete(COOKIE);
}
