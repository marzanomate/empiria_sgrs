export type DocType = {
  key: string;
  label: string;
  description: string;
};

export type SgrItem = {
  docKey: string;
  required: boolean;
  note?: string;
};

export type Sgr = {
  id: string;
  name: string;
  contactEmail?: string;
  items: SgrItem[];
  createdAt: string;
};

export type ReviewStatus = 'aprobado' | 'observado';

export type Review = {
  status: ReviewStatus;
  comment?: string;
  at: string; // ISO
};

export type Client = {
  id: string; // estable, usado para la carpeta de archivos
  token: string; // usado en el link único
  name: string;
  cuit: string;
  contactName?: string;
  email?: string;
  sgrIds: string[];
  active: boolean;
  createdAt: string;
  reviews: Record<string, Review>;
};

export type Db = {
  version: 1;
  docTypes: DocType[];
  sgrs: Sgr[];
  clients: Client[];
};

export type StoredFile = {
  pathname: string;
  docKey: string;
  name: string;
  size: number;
  uploadedAt: string;
};

export type DocStatus = 'pendiente' | 'en_revision' | 'aprobado' | 'observado';
