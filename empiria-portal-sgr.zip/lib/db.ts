import 'server-only';
import { get, put } from '@vercel/blob';
import crypto from 'crypto';
import { seedDb } from './defaults';
import type { Client, Db, DocType, Sgr } from './types';

const DB_PATH = 'sistema/db.json';

export async function readDb(): Promise<{ db: Db; etag?: string }> {
  const r = await get(DB_PATH, { access: 'private', useCache: false });
  if (!r || r.statusCode !== 200) return { db: seedDb() };
  const text = await new Response(r.stream).text();
  return { db: JSON.parse(text) as Db, etag: r.blob.etag };
}

export async function getDb(): Promise<Db> {
  return (await readDb()).db;
}

/**
 * Lee, aplica la modificación y escribe con control optimista (ifMatch).
 * Si otro usuario escribió en el medio, reintenta con la versión nueva.
 */
export async function mutateDb<T>(fn: (db: Db) => T | Promise<T>): Promise<T> {
  let lastErr: unknown;
  for (let i = 0; i < 4; i++) {
    const { db, etag } = await readDb();
    const result = await fn(db);
    try {
      await put(DB_PATH, JSON.stringify(db, null, 1), {
        access: 'private',
        addRandomSuffix: false,
        allowOverwrite: true,
        contentType: 'application/json',
        cacheControlMaxAge: 60,
        ...(etag ? { ifMatch: etag } : {}),
      });
      return result;
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, 150 * (i + 1)));
    }
  }
  throw lastErr;
}

export function newId(bytes = 9) {
  return crypto.randomBytes(bytes).toString('base64url');
}

export function newToken() {
  return crypto.randomBytes(18).toString('base64url');
}

export function findClientByToken(db: Db, token: string): Client | undefined {
  if (!token || token.length < 16) return undefined;
  return db.clients.find((c) => safeEqual(c.token, token));
}

function safeEqual(a: string, b: string) {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
}

/** Documentos que pide al menos una de las SGRs del cliente, en el orden del catálogo. */
export function requiredDocsForClient(db: Db, client: Client) {
  const sgrs = db.sgrs.filter((s) => client.sgrIds.includes(s.id));
  const map = new Map<
    string,
    { doc: DocType; required: boolean; bySgr: { sgr: Sgr; required: boolean; note?: string }[] }
  >();
  for (const doc of db.docTypes) {
    for (const sgr of sgrs) {
      const item = sgr.items.find((i) => i.docKey === doc.key);
      if (!item) continue;
      const entry = map.get(doc.key) ?? { doc, required: false, bySgr: [] };
      entry.required = entry.required || item.required;
      entry.bySgr.push({ sgr, required: item.required, note: item.note });
      map.set(doc.key, entry);
    }
  }
  return [...map.values()];
}

export function slugify(s: string) {
  return s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 40);
}
