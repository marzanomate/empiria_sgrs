import DeleteFileButton from '@/components/DeleteFileButton';
import DocUploader from '@/components/DocUploader';
import { findClientByToken, getDb, requiredDocsForClient } from '@/lib/db';
import { docStatus, groupByDoc, listClientFiles } from '@/lib/files';
import { formatBytes, formatDate, STATUS_LABEL } from '@/lib/format';

export const dynamic = 'force-dynamic';

function Shell({ children, subtitle }: { children: React.ReactNode; subtitle?: string }) {
  return (
    <>
      <header className="topbar">
        <div className="wrap">
          <span className="brand">EMPIRIA<small>{subtitle ?? 'Documentación para SGR'}</small></span>
        </div>
      </header>
      <main className="wrap" style={{ maxWidth: 860 }}>{children}</main>
      <footer className="foot">Empiria · Los archivos se guardan en forma privada y solo los ve el equipo de Empiria.</footer>
    </>
  );
}

export default async function ClientPortal({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const db = await getDb();
  const client = findClientByToken(db, token);

  if (!client || !client.active) {
    return (
      <Shell>
        <div className="card">
          <h2>Link no válido</h2>
          <p>Este link no existe o fue desactivado. Pedile uno nuevo a tu contacto en Empiria.</p>
        </div>
      </Shell>
    );
  }

  const files = groupByDoc(await listClientFiles(client.id));
  const docs = requiredDocsForClient(db, client);
  const statuses = docs.map((d) => ({ ...d, status: docStatus(client, d.doc.key, files[d.doc.key]) }));
  const req = statuses.filter((d) => d.required);
  const reqDone = req.filter((d) => d.status === 'aprobado' || d.status === 'en_revision').length;
  const observed = statuses.filter((d) => d.status === 'observado');
  const pct = req.length ? Math.round((100 * reqDone) / req.length) : 0;
  const sgrNames = db.sgrs.filter((s) => client.sgrIds.includes(s.id)).map((s) => s.name);

  // Primero lo observado, después lo pendiente, después el resto
  const order = { observado: 0, pendiente: 1, en_revision: 2, aprobado: 3 } as const;
  statuses.sort((a, b) => order[a.status] - order[b.status] || Number(b.required) - Number(a.required));

  return (
    <Shell subtitle={client.name}>
      <div className="card">
        <h1>Hola{client.contactName ? `, ${client.contactName.split(' ')[0]}` : ''}</h1>
        <p>
          Acá podés subir la documentación de <strong>{client.name}</strong> para presentar a{' '}
          {sgrNames.length ? sgrNames.join(', ') : 'las SGRs'}. Cada documento se sube una sola vez, aunque lo pidan varias SGRs.
          Podés volver a este link cuando quieras para completar lo que falte.
        </p>
        <div className="row between small" style={{ marginTop: 10 }}>
          <span>Obligatorios cargados: <strong>{reqDone} de {req.length}</strong></span>
          <span className="muted">{pct}%</span>
        </div>
        <div className="progress" style={{ marginTop: 6 }}><div className={pct === 100 ? 'ok' : ''} style={{ width: `${pct}%` }} /></div>
        {observed.length > 0 && (
          <div className="notice bad" style={{ marginTop: 14 }}>
            Hay {observed.length} documento(s) con observaciones. Revisalos abajo y volvé a subirlos.
          </div>
        )}
        {pct === 100 && observed.length === 0 && (
          <div className="notice ok" style={{ marginTop: 14 }}>¡Listo! Ya cargaste todo lo obligatorio. Te avisamos si hace falta algo más.</div>
        )}
      </div>

      {statuses.length === 0 && <div className="card muted">Todavía no hay documentos para cargar. Te avisamos cuando esté listo.</div>}

      {statuses.map(({ doc, required, bySgr, status }) => {
        const list = files[doc.key] ?? [];
        const review = client.reviews[doc.key];
        const notes = bySgr.filter((b) => b.note);
        return (
          <div className={`doc ${status}`} key={doc.key}>
            <div className="doc-head">
              <div>
                <h3>{doc.label} {required ? '' : <span className="muted small">(opcional)</span>}</h3>
                {doc.description && <div className="muted small">{doc.description}</div>}
                {notes.map((n) => (
                  <div className="small" key={n.sgr.id} style={{ marginTop: 4 }}><strong>{n.sgr.name}:</strong> {n.note}</div>
                ))}
              </div>
              <span className={`pill ${status}`}>{STATUS_LABEL[status]}</span>
            </div>
            {status === 'observado' && review?.comment && (
              <div className="notice bad small"><strong>Observación de Empiria:</strong> {review.comment}</div>
            )}
            {list.length > 0 && (
              <ul className="files">
                {list.map((f) => (
                  <li key={f.pathname}>
                    <a href={`/api/c/${token}/file?pathname=${encodeURIComponent(f.pathname)}`}>📄 {f.name}</a>
                    <span className="row" style={{ gap: 8 }}>
                      <span className="muted small">{formatBytes(f.size)} · {formatDate(f.uploadedAt)}</span>
                      {status !== 'aprobado' && <DeleteFileButton token={token} pathname={f.pathname} />}
                    </span>
                  </li>
                ))}
              </ul>
            )}
            {status !== 'aprobado' && <DocUploader token={token} clientId={client.id} docKey={doc.key} />}
          </div>
        );
      })}
    </Shell>
  );
}
