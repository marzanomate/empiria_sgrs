import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Empiria · Portal de documentación SGR',
  description: 'Carga de documentación para avales de Sociedades de Garantía Recíproca',
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
