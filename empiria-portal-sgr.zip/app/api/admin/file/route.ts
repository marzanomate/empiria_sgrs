import { isAdmin } from '@/lib/auth';
import { parsePathname, streamFile } from '@/lib/files';

export const runtime = 'nodejs';

export async function GET(req: Request) {
  if (!(await isAdmin())) return new Response('No autorizado', { status: 401 });
  const sp = new URL(req.url).searchParams;
  const pathname = sp.get('pathname') ?? '';
  const parsed = parsePathname(pathname);
  if (!parsed || pathname.includes('..')) return new Response('Ruta inválida', { status: 400 });
  return streamFile(pathname, parsed.name, sp.get('inline') === '1');
}
