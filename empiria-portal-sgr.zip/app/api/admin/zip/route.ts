import { get } from '@vercel/blob';
import { downloadZip } from 'client-zip';
import { isAdmin } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { docStatus, groupByDoc, listClientFiles } from '@/lib/files';
import { formatDate, STATUS_LABEL } from '@/lib/format';

export const runtime = 'nodejs';
export const maxDuration = 300;

function clean(s: string) {
  return s.replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, ' ').trim().slice(0, 90);
}

export async function GET(req: Request) {
  if (!(await isAdmin())) return new Response('No autorizado', { status: 401 });
  const sp = new URL(req.url).searchParams;
  const onlyApproved = sp.get('soloAprobados') === '1';

  const db = await getDb();
  const client = db.clients.find((c) => c.id === sp.get('client'));
  const sgr = db.sgrs.find((s) => s.id === sp.get('sgr'));
  if (!client || !sgr) return new Response('No encontrado', { status: 404 });

  const files = groupByDoc(await listClientFiles(client.id));
  const root = clean(`${client.name} - ${sgr.name}`);
  const today = new Date().toISOString().slice(0, 10);

  const lines: string[] = [
    `LEGAJO ${client.name.toUpperCase()}`,
    `CUIT: ${client.cuit || '-'}`,
    `Presentación a: ${sgr.name}`,
    `Generado: ${formatDate(new Date().toISOString())}${onlyApproved ? ' (solo documentos aprobados)' : ''}`,
    '',
    'N°  ESTADO        OBLIG.  DOCUMENTO',
  ];
  const missing: string[] = [];

  const entries: { folder: string; pathname: string; name: string; uploadedAt: string; size: number }[] = [];
  sgr.items.forEach((item, idx) => {
    const doc = db.docTypes.find((d) => d.key === item.docKey);
    if (!doc) return;
    const n = String(idx + 1).padStart(2, '0');
    const list = files[item.docKey] ?? [];
    const st = docStatus(client, item.docKey, list);
    lines.push(`${n}  ${STATUS_LABEL[st].padEnd(12)}  ${item.required ? 'Sí' : 'No'}      ${doc.label}${list.length ? ` (${list.length} archivo/s)` : ''}`);
    if (item.required && st !== 'aprobado') missing.push(`${n} - ${doc.label} (${STATUS_LABEL[st]})`);
    if (onlyApproved && st !== 'aprobado') return;
    const folder = `${root}/${n} - ${clean(doc.label)}`;
    for (const f of list) entries.push({ folder, pathname: f.pathname, name: clean(f.name), uploadedAt: f.uploadedAt, size: f.size });
  });

  lines.push('');
  if (missing.length) {
    lines.push('OBLIGATORIOS NO APROBADOS:');
    for (const m of missing) lines.push(`  - ${m}`);
  } else {
    lines.push('Todos los documentos obligatorios están aprobados.');
  }

  async function* gen() {
    yield { name: `${root}/00 - Indice del legajo.txt`, input: lines.join('\r\n'), lastModified: new Date() };
    const seen = new Set<string>();
    for (const e of entries) {
      const r = await get(e.pathname, { access: 'private' });
      if (!r || r.statusCode !== 200) continue;
      let name = `${e.folder}/${e.name}`;
      for (let i = 2; seen.has(name); i++) name = `${e.folder}/(${i}) ${e.name}`;
      seen.add(name);
      yield { name, input: r.stream, lastModified: new Date(e.uploadedAt), size: e.size };
    }
  }

  const zip = downloadZip(gen());
  const filename = `${clean(`Legajo ${client.name} - ${sgr.name}`)} ${today}.zip`;
  return new Response(zip.body, {
    headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`,
      'Cache-Control': 'private, no-store',
    },
  });
}
