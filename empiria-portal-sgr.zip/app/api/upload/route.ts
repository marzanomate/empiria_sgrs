import { handleUpload, type HandleUploadBody } from '@vercel/blob/client';
import { findClientByToken, getDb, requiredDocsForClient } from '@/lib/db';
import { ALLOWED_CONTENT_TYPES, clientPrefix, MAX_FILE_BYTES } from '@/lib/files';

export const runtime = 'nodejs';

const NAME_RE = /^\d{10,}-[A-Za-z0-9._ -]{1,120}$/;

export async function POST(request: Request) {
  const body = (await request.json()) as HandleUploadBody;
  try {
    const json = await handleUpload({
      body,
      request,
      onBeforeGenerateToken: async (pathname, clientPayload) => {
        const payload = JSON.parse(clientPayload ?? '{}') as { token?: string; docKey?: string };
        const db = await getDb();
        const client = findClientByToken(db, String(payload.token ?? ''));
        if (!client || !client.active) throw new Error('Link no válido');

        const docKey = String(payload.docKey ?? '');
        const allowed = requiredDocsForClient(db, client).some((d) => d.doc.key === docKey);
        if (!allowed) throw new Error('Documento no solicitado');
        if (client.reviews[docKey]?.status === 'aprobado') throw new Error('Ese documento ya fue aprobado');

        const prefix = `${clientPrefix(client.id)}${docKey}/`;
        const rest = pathname.slice(prefix.length);
        if (!pathname.startsWith(prefix) || !NAME_RE.test(rest) || rest.includes('..')) {
          throw new Error('Ruta inválida');
        }

        return {
          allowedContentTypes: ALLOWED_CONTENT_TYPES,
          maximumSizeInBytes: MAX_FILE_BYTES,
          addRandomSuffix: false,
          allowOverwrite: false,
          tokenPayload: JSON.stringify({ clientId: client.id, docKey }),
        };
      },
      onUploadCompleted: async () => {
        // El estado se deriva del listado de archivos: no hace falta escribir nada acá.
      },
    });
    return Response.json(json);
  } catch (error) {
    return Response.json({ error: (error as Error).message }, { status: 400 });
  }
}
