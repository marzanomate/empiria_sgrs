import { del } from '@vercel/blob';
import { findClientByToken, getDb } from '@/lib/db';
import { clientPrefix, parsePathname, streamFile } from '@/lib/files';

export const runtime = 'nodejs';

async function authorize(token: string, pathname: string) {
  const db = await getDb();
  const client = findClientByToken(db, token);
  if (!client || !client.active) return null;
  if (!pathname.startsWith(clientPrefix(client.id)) || pathname.includes('..')) return null;
  const parsed = parsePathname(pathname);
  if (!parsed) return null;
  return { client, parsed };
}

export async function GET(req: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const pathname = new URL(req.url).searchParams.get('pathname') ?? '';
  const ok = await authorize(token, pathname);
  if (!ok) return new Response('No autorizado', { status: 403 });
  return streamFile(pathname, ok.parsed.name);
}

export async function DELETE(req: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const pathname = new URL(req.url).searchParams.get('pathname') ?? '';
  const ok = await authorize(token, pathname);
  if (!ok) return new Response('No autorizado', { status: 403 });
  if (ok.client.reviews[ok.parsed.docKey]?.status === 'aprobado') {
    return new Response('Documento aprobado: no se puede borrar', { status: 409 });
  }
  await del(pathname);
  return Response.json({ ok: true });
}
