import { addDocType, updateDocTypes } from '../../actions';
import { requireAdmin } from '@/lib/auth';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function DocsPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  await requireAdmin();
  const { ok, error } = await searchParams;
  const db = await getDb();
  return (
    <>
      {ok === 'guardado' && <div className="notice ok">Cambios guardados.</div>}
      {ok === 'agregado' && <div className="notice ok">Documento agregado. Ahora incluilo en el checklist de las SGRs que lo pidan.</div>}
      {error === 'nombre' && <div className="notice bad">El nombre es obligatorio.</div>}
      <form action={addDocType} className="card">
        <h2>Agregar tipo de documento</h2>
        <div className="grid2">
          <div><label>Nombre *</label><input type="text" name="label" required /></div>
          <div><label>Descripción / instrucciones</label><input type="text" name="description" /></div>
        </div>
        <div style={{ marginTop: 14 }}><button className="btn" type="submit">Agregar</button></div>
      </form>
      <form action={updateDocTypes} className="card">
        <h2>Catálogo de documentos</h2>
        <p className="muted small">Es la lista común. Cada SGR elige cuáles pide desde su checklist.</p>
        <table>
          <thead><tr><th style={{ width: '40%' }}>Nombre</th><th>Descripción que ve el cliente</th></tr></thead>
          <tbody>
            {db.docTypes.map((d) => (
              <tr key={d.key}>
                <td><input type="text" name={`label_${d.key}`} defaultValue={d.label} /></td>
                <td><input type="text" name={`desc_${d.key}`} defaultValue={d.description} /></td>
              </tr>
            ))}
          </tbody>
        </table>
        <div style={{ marginTop: 14 }}><button className="btn" type="submit">Guardar cambios</button></div>
      </form>
    </>
  );
}
