import { createClient } from '../actions';
import { requireAdmin } from '@/lib/auth';
import { getDb, requiredDocsForClient } from '@/lib/db';
import { docStatus, groupByDoc, listClientFiles } from '@/lib/files';
import { formatDate } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function AdminHome({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  await requireAdmin();
  const { ok, error } = await searchParams;
  const db = await getDb();

  const rows = await Promise.all(
    db.clients.map(async (c) => {
      const files = groupByDoc(await listClientFiles(c.id));
      const docs = requiredDocsForClient(db, c);
      const req = docs.filter((d) => d.required);
      const st = docs.map((d) => ({ d, s: docStatus(c, d.doc.key, files[d.doc.key]) }));
      const approvedReq = st.filter((x) => x.d.required && x.s === 'aprobado').length;
      const toReview = st.filter((x) => x.s === 'en_revision').length;
      const observed = st.filter((x) => x.s === 'observado').length;
      const lastUpload = Object.values(files).flat().reduce((a, f) => (f.uploadedAt > a ? f.uploadedAt : a), '');
      return { c, reqTotal: req.length, approvedReq, toReview, observed, lastUpload };
    }),
  );
  rows.sort((a, b) => b.toReview - a.toReview || b.lastUpload.localeCompare(a.lastUpload));

  const totalToReview = rows.reduce((a, r) => a + r.toReview, 0);
  const complete = rows.filter((r) => r.reqTotal > 0 && r.approvedReq === r.reqTotal).length;

  return (
    <>
      {ok === 'borrado' && <div className="notice ok">Cliente eliminado junto con sus archivos.</div>}
      {error === 'nombre' && <div className="notice bad">El nombre del cliente es obligatorio.</div>}

      <div className="stats" style={{ marginBottom: 18 }}>
        <div className="card"><div className="muted small">Clientes</div><div className="stat">{rows.length}</div></div>
        <div className="card"><div className="muted small">Documentos por revisar</div><div className="stat">{totalToReview}</div></div>
        <div className="card"><div className="muted small">Legajos completos</div><div className="stat">{complete}</div></div>
        <div className="card"><div className="muted small">SGRs configuradas</div><div className="stat">{db.sgrs.length}</div></div>
      </div>

      <div className="card">
        <h2>Clientes</h2>
        {rows.length === 0 ? (
          <p className="muted">Todavía no hay clientes. Creá el primero abajo.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Cliente</th>
                <th>SGRs</th>
                <th style={{ width: 200 }}>Obligatorios aprobados</th>
                <th>Por revisar</th>
                <th>Última carga</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const pct = r.reqTotal ? Math.round((100 * r.approvedReq) / r.reqTotal) : 0;
                return (
                  <tr key={r.c.id}>
                    <td>
                      <a href={`/admin/clientes/${r.c.id}`}><strong>{r.c.name}</strong></a>
                      <div className="muted small">{r.c.cuit || 'Sin CUIT'}{!r.c.active && ' · link desactivado'}</div>
                    </td>
                    <td className="small">
                      {r.c.sgrIds.map((id) => db.sgrs.find((s) => s.id === id)?.name).filter(Boolean).map((n) => (
                        <span className="chip" key={n}>{n}</span>
                      ))}
                    </td>
                    <td>
                      <div className="progress"><div className={pct === 100 ? 'ok' : ''} style={{ width: `${pct}%` }} /></div>
                      <div className="muted small">{r.approvedReq}/{r.reqTotal}{r.observed > 0 && ` · ${r.observed} observados`}</div>
                    </td>
                    <td>{r.toReview > 0 ? <span className="pill en_revision">{r.toReview}</span> : <span className="muted">—</span>}</td>
                    <td className="small muted">{r.lastUpload ? formatDate(r.lastUpload) : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      <form action={createClient} className="card">
        <h2>Nuevo cliente</h2>
        <div className="grid2">
          <div><label>Razón social *</label><input type="text" name="name" required /></div>
          <div><label>CUIT</label><input type="text" name="cuit" placeholder="30-12345678-9" /></div>
          <div><label>Contacto</label><input type="text" name="contactName" /></div>
          <div><label>Email del contacto</label><input type="email" name="email" /></div>
        </div>
        <div style={{ marginTop: 14 }}>
          <label>SGRs a las que se presenta</label>
          {db.sgrs.length === 0 ? (
            <p className="muted small">Primero cargá al menos una SGR.</p>
          ) : (
            <div className="row">
              {db.sgrs.map((s) => (
                <label key={s.id} className="row" style={{ gap: 6, color: 'inherit', fontSize: '.92rem', marginRight: 14 }}>
                  <input type="checkbox" name="sgrIds" value={s.id} /> {s.name}
                </label>
              ))}
            </div>
          )}
        </div>
        <div style={{ marginTop: 16 }}><button className="btn" type="submit">Crear cliente y generar link</button></div>
      </form>
    </>
  );
}
