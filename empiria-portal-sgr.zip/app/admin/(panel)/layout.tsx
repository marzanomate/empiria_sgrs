import { redirect } from 'next/navigation';
import { clearAdminSession, requireAdmin } from '@/lib/auth';

export const dynamic = 'force-dynamic';

async function logout() {
  'use server';
  await clearAdminSession();
  redirect('/admin/login');
}

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  return (
    <>
      <header className="topbar">
        <div className="wrap">
          <a className="brand" href="/admin">EMPIRIA<small>Legajos SGR</small></a>
          <nav className="nav">
            <a href="/admin">Clientes</a>
            <a href="/admin/sgrs">SGRs</a>
            <a href="/admin/documentos">Documentos</a>
            <form action={logout}>
              <button className="btn secondary sm" type="submit">Salir</button>
            </form>
          </nav>
        </div>
      </header>
      <main className="wrap">{children}</main>
    </>
  );
}
