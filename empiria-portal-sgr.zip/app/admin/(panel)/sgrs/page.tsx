import { createSgr } from '../../actions';
import { requireAdmin } from '@/lib/auth';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function SgrsPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  await requireAdmin();
  const { ok, error } = await searchParams;
  const db = await getDb();
  return (
    <>
      {ok === 'borrado' && <div className="notice ok">SGR eliminada.</div>}
      {error === 'nombre' && <div className="notice bad">El nombre es obligatorio.</div>}
      <div className="card">
        <h2>SGRs</h2>
        <p className="muted small">Cada SGR tiene su checklist. El cliente ve la unión de lo que piden las SGRs a las que se presenta y sube cada documento una sola vez.</p>
        <table>
          <thead><tr><th>SGR</th><th>Documentos</th><th>Obligatorios</th><th>Clientes</th></tr></thead>
          <tbody>
            {db.sgrs.map((s) => (
              <tr key={s.id}>
                <td><a href={`/admin/sgrs/${s.id}`}><strong>{s.name}</strong></a>{s.contactEmail && <div className="muted small">{s.contactEmail}</div>}</td>
                <td>{s.items.length}</td>
                <td>{s.items.filter((i) => i.required).length}</td>
                <td>{db.clients.filter((c) => c.sgrIds.includes(s.id)).length}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <form action={createSgr} className="card">
        <h2>Nueva SGR</h2>
        <div className="grid2">
          <div><label>Nombre *</label><input type="text" name="name" required placeholder="Ej.: Garantizar SGR" /></div>
          <div><label>Email de presentación</label><input type="email" name="contactEmail" /></div>
          <div>
            <label>Copiar checklist de</label>
            <select name="baseId" defaultValue={db.sgrs[0]?.id ?? ''}>
              <option value="">Empezar vacío</option>
              {db.sgrs.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
        </div>
        <div style={{ marginTop: 16 }}><button className="btn" type="submit">Crear SGR</button></div>
      </form>
    </>
  );
}
