import { notFound } from 'next/navigation';
import { deleteSgr, updateSgr } from '../../../actions';
import { requireAdmin } from '@/lib/auth';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function SgrPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ ok?: string; error?: string }>;
}) {
  await requireAdmin();
  const { id } = await params;
  const { ok, error } = await searchParams;
  const db = await getDb();
  const sgr = db.sgrs.find((s) => s.id === id);
  if (!sgr) notFound();
  const users = db.clients.filter((c) => c.sgrIds.includes(sgr.id)).length;

  return (
    <>
      <p className="small"><a href="/admin/sgrs">← SGRs</a></p>
      {ok === 'guardado' && <div className="notice ok">Checklist guardado.</div>}
      {error === 'confirmar' && <div className="notice bad">Marcá la casilla de confirmación para eliminar.</div>}
      <form action={updateSgr} className="card">
        <input type="hidden" name="id" value={sgr.id} />
        <div className="grid2">
          <div><label>Nombre</label><input type="text" name="name" defaultValue={sgr.name} required /></div>
          <div><label>Email de presentación</label><input type="email" name="contactEmail" defaultValue={sgr.contactEmail} /></div>
        </div>
        <h2 style={{ marginTop: 22 }}>Checklist</h2>
        <p className="muted small">Tildá qué pide esta SGR y si es obligatorio. La nota se le muestra al cliente (por ejemplo: “formulario propio, descargarlo de su web”).</p>
        <table>
          <thead><tr><th style={{ width: 70 }}>Pide</th><th style={{ width: 90 }}>Obligatorio</th><th>Documento</th><th style={{ width: '34%' }}>Nota para el cliente</th></tr></thead>
          <tbody>
            {db.docTypes.map((d) => {
              const item = sgr.items.find((i) => i.docKey === d.key);
              return (
                <tr key={d.key}>
                  <td><input type="checkbox" name={`inc_${d.key}`} defaultChecked={!!item} /></td>
                  <td><input type="checkbox" name={`req_${d.key}`} defaultChecked={item ? item.required : true} /></td>
                  <td>{d.label}<div className="muted small">{d.description}</div></td>
                  <td><input type="text" name={`note_${d.key}`} defaultValue={item?.note} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <p className="small muted">¿Falta un documento? Agregalo en <a href="/admin/documentos">Documentos</a>.</p>
        <div style={{ marginTop: 10 }}><button className="btn" type="submit">Guardar checklist</button></div>
      </form>

      <details className="card">
        <summary style={{ color: 'var(--bad)' }}>Eliminar SGR</summary>
        <form action={deleteSgr} style={{ marginTop: 14 }}>
          <input type="hidden" name="id" value={sgr.id} />
          <p className="small">{users > 0 ? `La usan ${users} cliente(s); se les va a desasignar. ` : ''}Los archivos de los clientes no se borran.</p>
          <label className="row" style={{ gap: 6, color: 'inherit' }}><input type="checkbox" name="confirm" /> Confirmo</label>
          <div style={{ marginTop: 10 }}><button className="btn danger" type="submit">Eliminar SGR</button></div>
        </form>
      </details>
    </>
  );
}
