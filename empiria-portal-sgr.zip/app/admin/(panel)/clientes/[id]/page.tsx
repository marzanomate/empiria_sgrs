import { notFound } from 'next/navigation';
import { deleteClient, regenerateLink, reviewDoc, updateClient } from '../../../actions';
import CopyButton from '@/components/CopyButton';
import { requireAdmin } from '@/lib/auth';
import { getDb, requiredDocsForClient } from '@/lib/db';
import { docStatus, groupByDoc, listClientFiles } from '@/lib/files';
import { formatBytes, formatDate, STATUS_LABEL } from '@/lib/format';
import { baseUrl } from '@/lib/url';

export const dynamic = 'force-dynamic';

export default async function ClientPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ ok?: string; error?: string }>;
}) {
  await requireAdmin();
  const { id } = await params;
  const { ok, error } = await searchParams;
  const db = await getDb();
  const client = db.clients.find((c) => c.id === id);
  if (!client) notFound();

  const files = groupByDoc(await listClientFiles(client.id));
  const docs = requiredDocsForClient(db, client);
  const link = `${await baseUrl()}/c/${client.token}`;
  const sgrs = db.sgrs.filter((s) => client.sgrIds.includes(s.id));

  const perSgr = sgrs.map((s) => {
    const req = s.items.filter((i) => i.required);
    const approved = req.filter((i) => docStatus(client, i.docKey, files[i.docKey]) === 'aprobado').length;
    const uploaded = s.items.filter((i) => (files[i.docKey]?.length ?? 0) > 0).length;
    return { s, reqTotal: req.length, approved, uploaded };
  });

  return (
    <>
      <p className="small"><a href="/admin">← Clientes</a></p>
      {ok === 'guardado' && <div className="notice ok">Cambios guardados.</div>}
      {ok === 'link' && <div className="notice ok">Se generó un link nuevo. El anterior ya no funciona.</div>}
      {error === 'confirmar' && <div className="notice bad">Marcá la casilla de confirmación para eliminar.</div>}

      <div className="card">
        <div className="row between">
          <div>
            <h1>{client.name}</h1>
            <div className="muted">{client.cuit || 'Sin CUIT'}{client.contactName && ` · ${client.contactName}`}{client.email && ` · ${client.email}`}</div>
          </div>
          {!client.active && <span className="pill observado">Link desactivado</span>}
        </div>
        <div style={{ marginTop: 14 }}>
          <label>Link único del cliente</label>
          <div className="row">
            <div className="code" style={{ flex: 1 }}>{link}</div>
            <CopyButton text={link} />
            <form action={regenerateLink}>
              <input type="hidden" name="id" value={client.id} />
              <button className="btn secondary sm" type="submit">Generar link nuevo</button>
            </form>
          </div>
          <p className="muted small">Mandalo por mail al cliente. Cualquiera con el link puede subir archivos a este legajo.</p>
        </div>
      </div>

      <div className="card">
        <h2>Descargar legajo por SGR</h2>
        {perSgr.length === 0 && <p className="muted">El cliente no tiene SGRs asignadas.</p>}
        <table>
          <tbody>
            {perSgr.map(({ s, reqTotal, approved, uploaded }) => (
              <tr key={s.id}>
                <td><strong>{s.name}</strong><div className="muted small">{uploaded}/{s.items.length} con archivos · {approved}/{reqTotal} obligatorios aprobados</div></td>
                <td style={{ textAlign: 'right' }}>
                  <a className="btn sm" href={`/api/admin/zip?client=${client.id}&sgr=${s.id}`}>ZIP completo</a>{' '}
                  <a className="btn secondary sm" href={`/api/admin/zip?client=${client.id}&sgr=${s.id}&soloAprobados=1`}>Solo aprobados</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2 style={{ margin: '26px 0 12px' }}>Documentación</h2>
      {docs.length === 0 && <div className="card muted">No hay documentos pedidos: asigná SGRs al cliente.</div>}
      {docs.map(({ doc, required, bySgr }) => {
        const list = files[doc.key] ?? [];
        const st = docStatus(client, doc.key, list);
        const review = client.reviews[doc.key];
        return (
          <div className={`doc ${st}`} key={doc.key} id={`doc-${doc.key}`}>
            <div className="doc-head">
              <div>
                <h3>{doc.label} {!required && <span className="muted small">(opcional)</span>}</h3>
                <div>
                  {bySgr.map((b) => (
                    <span key={b.sgr.id} className={`chip ${b.required ? 'req' : ''}`} title={b.note}>{b.sgr.name}{b.required ? '' : ' · opc.'}</span>
                  ))}
                </div>
              </div>
              <span className={`pill ${st}`}>{STATUS_LABEL[st]}</span>
            </div>
            {review?.status === 'observado' && review.comment && (
              <div className="notice bad small">Observación enviada: {review.comment}</div>
            )}
            {list.length > 0 && (
              <ul className="files">
                {list.map((f) => (
                  <li key={f.pathname}>
                    <span>📄 {f.name} <span className="muted small">· {formatBytes(f.size)} · {formatDate(f.uploadedAt)}</span></span>
                    <span className="row" style={{ gap: 6 }}>
                      <a className="btn secondary sm" target="_blank" href={`/api/admin/file?pathname=${encodeURIComponent(f.pathname)}&inline=1`}>Ver</a>
                      <a className="btn secondary sm" href={`/api/admin/file?pathname=${encodeURIComponent(f.pathname)}`}>Bajar</a>
                    </span>
                  </li>
                ))}
              </ul>
            )}
            {list.length > 0 && (
              <form action={reviewDoc} className="row" style={{ marginTop: 12 }}>
                <input type="hidden" name="id" value={client.id} />
                <input type="hidden" name="docKey" value={doc.key} />
                <input type="text" name="comment" placeholder="Observación para el cliente (si corresponde)" style={{ flex: 1, minWidth: 220 }} />
                <button className="btn ok sm" name="action" value="aprobado" type="submit">Aprobar</button>
                <button className="btn danger sm" name="action" value="observado" type="submit">Observar</button>
                {review && <button className="btn secondary sm" name="action" value="reset" type="submit">Deshacer</button>}
              </form>
            )}
          </div>
        );
      })}

      <details className="card" style={{ marginTop: 26 }}>
        <summary>Editar datos del cliente</summary>
        <form action={updateClient} style={{ marginTop: 14 }}>
          <input type="hidden" name="id" value={client.id} />
          <div className="grid2">
            <div><label>Razón social</label><input type="text" name="name" defaultValue={client.name} required /></div>
            <div><label>CUIT</label><input type="text" name="cuit" defaultValue={client.cuit} /></div>
            <div><label>Contacto</label><input type="text" name="contactName" defaultValue={client.contactName} /></div>
            <div><label>Email</label><input type="email" name="email" defaultValue={client.email} /></div>
          </div>
          <div style={{ marginTop: 14 }}>
            <label>SGRs</label>
            <div className="row">
              {db.sgrs.map((s) => (
                <label key={s.id} className="row" style={{ gap: 6, color: 'inherit', fontSize: '.92rem', marginRight: 14 }}>
                  <input type="checkbox" name="sgrIds" value={s.id} defaultChecked={client.sgrIds.includes(s.id)} /> {s.name}
                </label>
              ))}
            </div>
          </div>
          <label className="row" style={{ gap: 6, color: 'inherit', marginTop: 14 }}>
            <input type="checkbox" name="active" defaultChecked={client.active} /> Link activo (el cliente puede ingresar y subir)
          </label>
          <div style={{ marginTop: 14 }}><button className="btn" type="submit">Guardar</button></div>
        </form>
      </details>

      <details className="card">
        <summary style={{ color: 'var(--bad)' }}>Eliminar cliente</summary>
        <form action={deleteClient} style={{ marginTop: 14 }}>
          <input type="hidden" name="id" value={client.id} />
          <p className="small">Se borran el cliente y <strong>todos sus archivos</strong>. No se puede deshacer.</p>
          <label className="row" style={{ gap: 6, color: 'inherit' }}><input type="checkbox" name="confirm" /> Confirmo que quiero eliminarlo</label>
          <div style={{ marginTop: 10 }}><button className="btn danger" type="submit">Eliminar definitivamente</button></div>
        </form>
      </details>
    </>
  );
}
