'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { requireAdmin } from '@/lib/auth';
import { mutateDb, newId, newToken, slugify } from '@/lib/db';
import { deleteClientFolder } from '@/lib/files';
import type { ReviewStatus, SgrItem } from '@/lib/types';

const str = (f: FormData, k: string, max = 300) => String(f.get(k) ?? '').trim().slice(0, max);

/* ---------- Clientes ---------- */

export async function createClient(formData: FormData) {
  await requireAdmin();
  const name = str(formData, 'name', 160);
  if (!name) redirect('/admin?error=nombre');
  const id = await mutateDb((db) => {
    const validSgrs = new Set(db.sgrs.map((s) => s.id));
    const client = {
      id: newId(),
      token: newToken(),
      name,
      cuit: str(formData, 'cuit', 20),
      contactName: str(formData, 'contactName', 120),
      email: str(formData, 'email', 160),
      sgrIds: formData.getAll('sgrIds').map(String).filter((s) => validSgrs.has(s)),
      active: true,
      createdAt: new Date().toISOString(),
      reviews: {},
    };
    db.clients.push(client);
    return client.id;
  });
  redirect(`/admin/clientes/${id}`);
}

export async function updateClient(formData: FormData) {
  await requireAdmin();
  const id = str(formData, 'id');
  await mutateDb((db) => {
    const c = db.clients.find((x) => x.id === id);
    if (!c) return;
    const validSgrs = new Set(db.sgrs.map((s) => s.id));
    c.name = str(formData, 'name', 160) || c.name;
    c.cuit = str(formData, 'cuit', 20);
    c.contactName = str(formData, 'contactName', 120);
    c.email = str(formData, 'email', 160);
    c.sgrIds = formData.getAll('sgrIds').map(String).filter((s) => validSgrs.has(s));
    c.active = formData.get('active') === 'on';
  });
  revalidatePath(`/admin/clientes/${id}`);
  redirect(`/admin/clientes/${id}?ok=guardado`);
}

export async function regenerateLink(formData: FormData) {
  await requireAdmin();
  const id = str(formData, 'id');
  await mutateDb((db) => {
    const c = db.clients.find((x) => x.id === id);
    if (c) c.token = newToken();
  });
  redirect(`/admin/clientes/${id}?ok=link`);
}

export async function deleteClient(formData: FormData) {
  await requireAdmin();
  const id = str(formData, 'id');
  if (formData.get('confirm') !== 'on') redirect(`/admin/clientes/${id}?error=confirmar`);
  await deleteClientFolder(id);
  await mutateDb((db) => {
    db.clients = db.clients.filter((c) => c.id !== id);
  });
  redirect('/admin?ok=borrado');
}

export async function reviewDoc(formData: FormData) {
  await requireAdmin();
  const id = str(formData, 'id');
  const docKey = str(formData, 'docKey', 60);
  const action = str(formData, 'action', 20);
  const comment = str(formData, 'comment', 1000);
  await mutateDb((db) => {
    const c = db.clients.find((x) => x.id === id);
    if (!c) return;
    if (action === 'reset') {
      delete c.reviews[docKey];
      return;
    }
    const status: ReviewStatus = action === 'aprobado' ? 'aprobado' : 'observado';
    c.reviews[docKey] = { status, comment: status === 'observado' ? comment : undefined, at: new Date().toISOString() };
  });
  revalidatePath(`/admin/clientes/${id}`);
  redirect(`/admin/clientes/${id}#doc-${docKey}`);
}

/* ---------- SGRs ---------- */

export async function createSgr(formData: FormData) {
  await requireAdmin();
  const name = str(formData, 'name', 120);
  const baseId = str(formData, 'baseId');
  if (!name) redirect('/admin/sgrs?error=nombre');
  const id = await mutateDb((db) => {
    const base = db.sgrs.find((s) => s.id === baseId);
    const sgr = {
      id: newId(6),
      name,
      contactEmail: str(formData, 'contactEmail', 160),
      items: base ? base.items.map((i) => ({ ...i })) : [],
      createdAt: new Date().toISOString(),
    };
    db.sgrs.push(sgr);
    return sgr.id;
  });
  redirect(`/admin/sgrs/${id}`);
}

export async function updateSgr(formData: FormData) {
  await requireAdmin();
  const id = str(formData, 'id');
  await mutateDb((db) => {
    const s = db.sgrs.find((x) => x.id === id);
    if (!s) return;
    s.name = str(formData, 'name', 120) || s.name;
    s.contactEmail = str(formData, 'contactEmail', 160);
    const items: SgrItem[] = [];
    for (const d of db.docTypes) {
      if (formData.get(`inc_${d.key}`) !== 'on') continue;
      items.push({
        docKey: d.key,
        required: formData.get(`req_${d.key}`) === 'on',
        note: str(formData, `note_${d.key}`, 400) || undefined,
      });
    }
    s.items = items;
  });
  revalidatePath(`/admin/sgrs/${id}`);
  redirect(`/admin/sgrs/${id}?ok=guardado`);
}

export async function deleteSgr(formData: FormData) {
  await requireAdmin();
  const id = str(formData, 'id');
  if (formData.get('confirm') !== 'on') redirect(`/admin/sgrs/${id}?error=confirmar`);
  await mutateDb((db) => {
    db.sgrs = db.sgrs.filter((s) => s.id !== id);
    for (const c of db.clients) c.sgrIds = c.sgrIds.filter((s) => s !== id);
  });
  redirect('/admin/sgrs?ok=borrado');
}

/* ---------- Tipos de documento ---------- */

export async function addDocType(formData: FormData) {
  await requireAdmin();
  const label = str(formData, 'label', 160);
  if (!label) redirect('/admin/documentos?error=nombre');
  await mutateDb((db) => {
    let key = slugify(label) || newId(4);
    while (db.docTypes.some((d) => d.key === key)) key = `${key}_${newId(2).toLowerCase()}`;
    db.docTypes.push({ key, label, description: str(formData, 'description', 400) });
  });
  redirect('/admin/documentos?ok=agregado');
}

export async function updateDocTypes(formData: FormData) {
  await requireAdmin();
  await mutateDb((db) => {
    for (const d of db.docTypes) {
      const label = str(formData, `label_${d.key}`, 160);
      if (label) d.label = label;
      d.description = str(formData, `desc_${d.key}`, 400);
    }
  });
  redirect('/admin/documentos?ok=guardado');
}
