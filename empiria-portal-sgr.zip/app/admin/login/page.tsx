import { redirect } from 'next/navigation';
import { checkPassword, isAdmin, setAdminSession } from '@/lib/auth';

export const dynamic = 'force-dynamic';

async function login(formData: FormData) {
  'use server';
  const pass = String(formData.get('password') ?? '');
  if (!checkPassword(pass)) {
    await new Promise((r) => setTimeout(r, 900));
    redirect('/admin/login?error=1');
  }
  await setAdminSession();
  redirect('/admin');
}

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if (await isAdmin()) redirect('/admin');
  const { error } = await searchParams;
  return (
    <>
      <header className="topbar">
        <div className="wrap">
          <span className="brand">EMPIRIA<small>Panel interno</small></span>
        </div>
      </header>
      <main className="wrap">
        <form action={login} className="card" style={{ maxWidth: 400, margin: '40px auto' }}>
          <h2>Ingresar al panel</h2>
          {error && <div className="notice bad">Contraseña incorrecta.</div>}
          <label htmlFor="password">Contraseña del equipo</label>
          <input id="password" name="password" type="password" required autoFocus />
          <div style={{ marginTop: 16 }}>
            <button className="btn" type="submit">Ingresar</button>
          </div>
        </form>
      </main>
    </>
  );
}
