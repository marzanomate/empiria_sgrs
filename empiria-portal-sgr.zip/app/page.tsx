export default function Home() {
  return (
    <>
      <header className="topbar">
        <div className="wrap">
          <span className="brand">EMPIRIA<small>Portal de documentación SGR</small></span>
        </div>
      </header>
      <main className="wrap">
        <div className="card" style={{ maxWidth: 620 }}>
          <h1>Portal de documentación</h1>
          <p>
            Si sos cliente de Empiria, ingresá con el link personal que te enviamos por correo. Ese link es
            privado: no lo compartas.
          </p>
          <p className="muted small">¿Perdiste tu link? Escribile a tu contacto en Empiria y te mandamos uno nuevo.</p>
          <p style={{ marginTop: 24 }}>
            <a className="btn secondary sm" href="/admin">Acceso equipo Empiria</a>
          </p>
        </div>
      </main>
    </>
  );
}
